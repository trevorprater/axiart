---
name: axiart-generator
description: Generate algorithmic artwork using the AxiArt system for pen plotting. Use this skill when the user requests generative art, portraits, landscapes, or algorithmic compositions. The output style is inspired by technical/architectural drawings with dense layered mark-making, geometric infrastructure, and strategic hand-coloring zones.
---

# AxiArt Generator: Technical Algorithmic Art for Pen Plotting

## Core Aesthetic Philosophy

This skill generates artwork in the style of **technical/architectural drawings meets algorithmic art** - think engineering schematics that document invisible processes through dense, layered mark-making.

**Reference aesthetic:** The "Ghost of the Machine" series by Martin DeVido (from X/Twitter) - geometric grids overlaid with organic patterns, clinical annotations, strategic color zones, dense accumulation creating visual weight.

**Key characteristics:**
- **Dense layering** (15,000-30,000+ marks) creating depth through overlapping systems
- **Geometric infrastructure** (grids, circles, reference lines) as compositional scaffolding
- **Clinical aesthetic** (coordinates, measurement ticks, annotations) treating subjects as specimens
- **Strategic color zones** (2-3 colors maximum, used structurally not decoratively)
- **Pattern interplay** (organic forms constrained by/breaking through geometric boundaries)
- **Technical precision** meets algorithmic chaos

## Setup and Installation

```bash
uv pip install git+https://github.com/trevorprater/axiart.git
```

Before generating, review the AxiArt API:
- Repository: https://github.com/trevorprater/axiart
- Read `CLAUDE.md` for API documentation
- Check `axiart/patterns/` for available pattern types

**Note:** Repo examples demonstrate API usage only, not this skill's aesthetic philosophy.

## When to Use This Skill

Trigger on requests for:
- Portraits, self-portraits, faces
- Landscapes, scenes, environments  
- Abstract algorithmic art
- "Generate artwork about [concept]"
- Pen plotter artwork, generative art, SVG art

## Design Process

### Step 1: Define the Technical Specimen

Frame the subject as a **technical documentation of an invisible process**:

**For portraits:**
"Documenting the architecture of consciousness" - not drawing a face, but mapping the invisible: neural firing patterns, recursive thought loops, the geometry of attention.

**For landscapes:**
"Cartography of forces" - not depicting scenery, but documenting invisible forces: wind flow, geological pressure, erosion patterns, electromagnetic fields.

**For abstract concepts:**
"Specimen documentation" - treating abstract ideas (memory, anxiety, emergence) as measurable phenomena with observable structure.

**The framing determines everything:** You're not making art *of* something, you're creating technical documentation that reveals its hidden architecture.

### Step 2: Design the Geometric Infrastructure

Every piece needs **geometric scaffolding** - the clinical framework that makes it feel like technical documentation:

**Grid systems** (foundation layer, subtle):
- Square grids (8-15mm cells) across entire canvas, light gray, 0.2-0.3mm stroke
- Creates the "measurement substrate" - like graph paper for scientific observation
- Can be jittered slightly for organic feel

**Reference geometry** (structural layer):
- Circles, rectangles, polygons that define **conceptual zones**
- Example (portrait): 3-4 circles representing "processing zones" (eyes, consciousness center)
- Example (landscape): Horizontal bands representing depth layers
- These are filled shapes (light tint) with darker stroke outline
- Patterns will be constrained to/growing from these zones

**Clinical annotations** (detail layer):
- Coordinate markers at key points: small circles (1-2mm) with crosshairs
- Measurement ticks along edges (every 10-20mm)
- Index numbers or labels (optional, very sparse)
- Creates the "this is data" aesthetic

**Accent geometry** (tension layer):
- 2-5 bold lines (0.5-0.8mm stroke) in accent color (blue, purple, gold)
- These mark boundaries, connections, or flow between zones
- Diagonal lines, curves connecting geometric zones, or emphasis marks

### Step 3: Layer Dense Pattern Systems

Now fill the infrastructure with **dense algorithmic mark-making** (this is where the 15k-30k marks come from):

**Primary pattern system** (60% of organic marks = 9,000-18,000 marks):
Choose ONE pattern type that best documents the invisible process:

- **Fermat spirals** (2,000-4,000 points each): For focal points, observation, recursive processes
  - Place at geometric zone centers (eyes, convergence points)
  - Vary spacing to create density gradients (tight center, loose edge)
  
- **Flow fields** (1,500-3,000 streamlines, 50-150 steps each): For forces, movement, propagation
  - Use noise-based fields for organic flow
  - Constrain to specific geometric zones or between zones
  
- **Dendrites** (3,000-5,000 particles): For growth, branching, network structures
  - Seed from geometric zone boundaries
  - Multiple systems with different parameters overlapping
  
- **Noise contours** (20-40 levels): For topology, depth, texture, degradation
  - Creates topographic-style nested lines
  - Can suggest depth, wear, corruption

**Secondary pattern system** (30% of organic marks = 4,500-9,000 marks):
Choose a DIFFERENT pattern type that **interacts with** the primary:

- If primary is spirals (focal/ordered), secondary could be dendrites (branching/chaotic)
- If primary is flow fields (directional), secondary could be contours (layered depth)
- The interaction creates visual interest: order vs chaos, growth vs constraint, etc.

**Tertiary pattern** (10% of organic marks = 1,500-3,000 marks):
Optional third system for additional complexity, usually the lightest/most sparse

## CRITICAL FIX: Spiral Rendering

**Problem:** Drawing spirals with `as_points=True` creates stippled dots that lose the spiral structure.

**Solution:** Draw spirals as CONTINUOUS CURVES to preserve rotational form:

```python
# ❌ BAD: Loses spiral structure
spiral.draw(canvas, "primary_pattern", as_points=True)
# Result: Dot cloud, no visible rotation

# ✅ GOOD: Preserves spiral arms
spiral.generate_fermat_spiral(num_points=2500, spacing=1.5)
paths = spiral.get_spirals()  # Get the actual spiral curves
for spiral_path in paths:
    canvas.add_polyline(spiral_path, "primary_pattern")
# Result: Visible rotational structure, recognizable as spiral
```

**For Fermat spirals specifically:**
- Use 2000-4000 points with spacing 1.2-2.0
- Draw as polylines, NOT as point clouds
- Multiple overlapping spirals (2-3) in each zone create depth
- The spiral arms should be VISIBLE, not dissolved into stippling

**When to use as_points=True:**
- For secondary dense textures/stippling effects only
- Creates dotted appearance - use sparingly for atmospheric effects
- NOT for primary structural patterns where form matters

## CRITICAL FIX: Form Through Density, Not Opaque Geometry

**Problem:** Using opaque `add_filled_shape()` creates hard geometric voids that patterns flow around, making compositions feel like pattern demonstrations arranged around arbitrary shapes.

**Solution:** Use semi-transparent fills that patterns draw OVER, so form emerges from mark density:

```python
# ❌ BAD: Opaque filled shapes (from axiart examples)
from axiart.shapes import Circle, add_filled_shape
left_eye = Circle((cx - 40, cy - 30), 35)
add_filled_shape(canvas, left_eye,
                 fill_color="#F5F7FA",  # Opaque fill
                 stroke_color="#2E4A6D",
                 stroke_width=0.6)
# Result: Hard geometric void. Patterns avoid the circle.
#         Form is geometric, not organic.

# ✅ GOOD: Semi-transparent color zones via canvas.dwg.add()
canvas.dwg.add(canvas.dwg.circle(
    center=(cx - 40, cy - 30),
    r=35,
    fill="#E3F2FD",      # Very light blue tint
    opacity=0.25,        # Nearly transparent (0.2-0.3 range)
    stroke="#2E4A6D",    # Blue accent outline
    stroke_width=0.6
))
# Then draw patterns ON TOP in black - they overlap the zone
# Result: Form emerges from dense spiral marks, not from geometric shape.
#         The tinted circle is a subtle background, not a void.
```

**Key insight:** Layer opacity doesn't work (`comp.add_layer(opacity=0.5)` is stored but not applied). Instead, use per-element opacity via `canvas.dwg.add()` for semi-transparent fills.

**Guidelines:**
- Color zone fills: opacity 0.2-0.35 (very subtle tint)
- Accent stroke outlines: opacity 1.0 (solid, visible)
- The geometric zones should be barely visible background hints, not dominant shapes
- Patterns draw OVER the zones, creating the actual visual mass

### Step 4: Define Color Strategy

**Base palette: Black + 1-2 accent colors**

**Color allocation (for hand-coloring after plotting):**

1. **Black ink** (all base patterns):
   - Grid infrastructure
   - Primary and secondary organic patterns
   - Clinical annotations
   - Most geometric boundaries

2. **Accent color 1** (structural, ~5-10% of marked area):
   - Key geometric zone boundaries (circles, important shapes)
   - Accent lines connecting zones
   - Highlight marks emphasizing focal points
   - Example: Blue for "neural/electric", Purple for "consciousness", Gold for "energy"

3. **Accent color 2** (optional, ~5% of marked area):
   - Secondary structural elements
   - Creates temperature contrast (cool + warm)
   - Example: Blue (primary) + Warm orange/red (secondary)

**Color zones are defined in the composition, user hand-colors after plotting.**

### Step 5: Spatial Filtering and Density Mapping

**Critical:** Patterns must be **spatially constrained** to create visual hierarchy:

**Dense zones** (inside geometric zones, focal areas):
- 10,000-15,000 marks/mm² 
- Primary + secondary patterns at full density
- Example: Inside eye circles, dense spiral + flow field overlay

**Medium zones** (transitions, between geometric zones):
- 3,000-7,000 marks/mm²
- Filtered patterns (render 50-70% of generated marks)
- Example: Patterns connecting geometric zones

**Sparse zones** (margins, backgrounds, voids):
- 500-2,000 marks/mm²
- Grid only, or highly filtered patterns (render 10-30%)
- Example: Canvas corners, areas outside main geometric zones

**Implementation via filtering:**
```python
# Example: Constrain flow field to inside circles
for path in flow_paths:
    # Check if path is inside any of the geometric zones
    path_center = (sum(x for x,y in path)/len(path), sum(y for x,y in path)/len(path))
    
    inside_zone = any(
        point_in_circle(path_center[0], path_center[1], zone.cx, zone.cy, zone.r)
        for zone in geometric_zones
    )
    
    if inside_zone:
        canvas.add_polyline(path, "primary_pattern")  # Dense zone
    elif random.random() < 0.3:  # 30% chance for transition zones
        canvas.add_polyline(path, "primary_pattern")
```

## Composition Templates by Subject Type

### Portrait / Self-Portrait

**Geometric infrastructure:**
- 3-4 filled circles representing "processing zones"
  - Two upper circles (cx ± 40, cy - 30) = "observation zones" (eyes)
  - One central circle (cx, cy + 10) = "integration zone" (cognitive center)
  - Optional: smaller circle above (cx, cy - 60) = "executive function"
- Vertical orientation emphasizing head/consciousness
- Grid background (10mm cells) across entire canvas
- 4-6 accent lines (blue) connecting the zones (neural pathways)

**Pattern strategy:**
- **Primary: Fermat spirals** (2,500 points each) inside the 2-3 main circles
  - Dense, tight spacing (1.2-1.8) = intense focal activity
  - These become the "eyes" or attention centers
  - IMPORTANT: Draw as continuous polylines, NOT as point clouds
  
- **Secondary: Dendrites** (4,000 particles, 2-3 systems)
  - Seed from circle boundaries, grow outward/downward
  - Branching networks suggesting neural connections
  - Radial style for organic spreading
  
- **Tertiary: Flow fields** (1,000 streamlines)
  - Between circles, suggesting information flow
  - Constrained to not enter circle interiors (spirals are there)

**Total marks:** ~20,000-25,000 (spirals 7,500 + dendrites 4,000 + flow 8,000 + grid 500 + annotations 200)

**Color zones:**
- Blue: Circle outlines + connecting accent lines
- Optional purple/gold: Highlight one circle or dendrite region

### Landscape / Environment

**Geometric infrastructure:**
- Horizontal bands (2-4 rectangles) representing depth layers
  - Sky layer (upper 40%): light tint
  - Mid-ground (middle 30%): slightly darker
  - Foreground (lower 30%): darkest tint
- Horizontal grid (15mm cells) emphasizing landscape orientation
- Vertical measurement ticks on sides (every 10mm)
- Horizon line emphasized with bold accent color line

**Pattern strategy:**
- **Primary: Noise contours** (30-40 levels)
  - Dense in foreground, sparse in sky
  - Creates topographic depth mapping
  - Filtered to be denser in lower zones
  
- **Secondary: Flow fields** (2,000 streamlines)
  - Horizontal flow in sky (wind, atmosphere)
  - Vertical flow from horizon up (heat, energy rising)
  - Turbulent in foreground
  
- **Tertiary: Dendrites** (2,000 particles)
  - Seed from horizon line upward (trees, vegetation, structures)
  - Vertical branching from ground plane

**Total marks:** ~25,000-30,000

**Color zones:**
- Blue: Horizon line + sky elements
- Warm (orange/gold): Foreground accents

### Abstract Concept

**Geometric infrastructure:**
- Custom based on concept, but needs clear geometric framework
- Example (memory): Overlapping circles of different sizes (memory clusters)
- Example (emergence): Triangular zones converging toward a point
- Grid background always
- Annotations labeling zones (optional)

**Pattern strategy:**
- Choose 2-3 patterns that metaphorically map to the concept
- Use geometric zones to create conceptual regions
- Dense/sparse filtering to create visual narrative

## Layer Architecture

Standard layer setup (7-9 layers for depth):

```python
comp.add_layer("grid", color="#CCCCCC", stroke_width=0.2, opacity=0.5)
comp.add_layer("geo_fills", color="none")  # Filled geometric zones
comp.add_layer("geo_strokes", color="black", stroke_width=0.4)
comp.add_layer("primary_pattern", color="black", stroke_width=0.25)
comp.add_layer("secondary_pattern", color="black", stroke_width=0.2)
comp.add_layer("tertiary_pattern", color="black", stroke_width=0.2, opacity=0.7)
comp.add_layer("annotations", color="black", stroke_width=0.3)
comp.add_layer("accent_color", color="#2E4A6D", stroke_width=0.6)  # Blue accent
comp.add_layer("accent_color_2", color="#C17B3A", stroke_width=0.5)  # Optional warm
```

## Mark Budget Guidelines

**Target: 15,000-30,000 total marks for visual richness**

Breakdown by component:
- Grid foundation: 400-800 marks (subtle but present)
- Geometric infrastructure: 300-600 marks (circles, rectangles, lines)
- Primary pattern: 9,000-18,000 marks (the visual anchor)
- Secondary pattern: 4,500-9,000 marks (adds complexity)
- Tertiary pattern: 1,500-3,000 marks (optional extra depth)
- Annotations: 100-300 marks (clinical details)
- Accent elements: 200-500 marks (structural color zones)

**File size: 3-8 MB typical** (dense compositions create larger files)

**Plotting time: 2-4 hours** at default AxiDraw speeds

## Critical Reminders

1. **Always include geometric infrastructure** - grid + reference shapes + annotations
2. **Layer 2-3 dense pattern systems** - overlapping creates depth
3. **Spatially filter patterns** - create dense/medium/sparse zones
4. **Define color zones structurally** - accent colors mark boundaries/connections
5. **Total marks: 15k-30k** - visual richness requires density
6. **Think like technical documentation** - mapping invisible architecture
7. **Geometric zones guide organic patterns** - constraint creates interplay

## Output Requirements

Every generation produces:

1. **SVG file** (`{name}.svg`) - the artwork
2. **Philosophy document** (`{name}_philosophy.md`) - concept + technical notes
3. **Generation report** with statistics:

```
✓ [ARTWORK TITLE]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Subject: [Portrait/Landscape/Abstract]
Concept: [One sentence describing what's being documented]

GEOMETRIC INFRASTRUCTURE:
- Grid: [cell size]mm, [line count] lines
- Reference geometry: [shapes used and why]
- Annotations: [count] markers

PATTERN SYSTEMS:
- Primary: [pattern type], ~[count] marks
- Secondary: [pattern type], ~[count] marks  
- Tertiary: [pattern type], ~[count] marks (if used)

COLOR STRATEGY:
- Base: Black
- Accent 1: [color] for [structural purpose]
- Accent 2: [color] for [purpose] (if used)

DENSITY DISTRIBUTION:
- Dense zones: [description of where]
- Medium zones: [description]
- Sparse zones: [description]

TOTAL MARKS: ~[count] elements
FILE SIZE: [size] MB
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Output: {filename}.svg
Ready for plotting + hand-coloring
```

## PNG Preview Generation

After saving the SVG, automatically generate a PNG preview for easy viewing:

```python
import subprocess
import os

def generate_png_preview(svg_path, png_path=None, width=2400):
    """
    Generate PNG preview from SVG using Inkscape or cairosvg

    Args:
        svg_path: Path to the SVG file
        png_path: Output PNG path (defaults to same name as SVG)
        width: Width in pixels (default 2400 for high quality)
    """
    if png_path is None:
        png_path = svg_path.replace('.svg', '.png')

    # Try Inkscape first (best quality)
    try:
        subprocess.run([
            'inkscape',
            '--export-type=png',
            f'--export-width={width}',
            '--export-filename=' + png_path,
            svg_path
        ], check=True, capture_output=True)
        print(f"✓ PNG preview: {png_path}")
        return png_path
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Fallback to cairosvg
    try:
        import cairosvg
        cairosvg.svg2png(
            url=svg_path,
            write_to=png_path,
            output_width=width
        )
        print(f"✓ PNG preview: {png_path}")
        return png_path
    except ImportError:
        print("⚠ Could not generate PNG - install cairosvg or inkscape")
        print(f"  pip install cairosvg")
        return None
```

**Usage in template:**

Add this to the end of the `main()` function, right after `comp.save()`:

```python
# Save SVG
output_path = "[filename].svg"
comp.save(output_path)

# Generate PNG preview
generate_png_preview(output_path)
```

This will automatically create a `.png` file alongside every `.svg` with the same name. The PNG will be high-resolution (2400px wide) for quality viewing but much easier to preview than SVGs.

If neither Inkscape nor cairosvg is available, it'll warn but won't crash - the SVG still gets created.

## Implementation Template

```python
"""
[Title] - [Subject Type]

Technical Documentation Of: [What invisible process/architecture is being mapped]

Geometric Infrastructure: [Grid + reference shapes strategy]
Pattern Strategy: [2-3 patterns and their roles]
Color Strategy: [Accent colors and their structural purpose]
"""

import sys, os, random, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from axiart.composition import Composition
from axiart.patterns.spiral import SpiralPattern
from axiart.patterns.flow_field import FlowFieldPattern
from axiart.patterns.dendrite import DendritePattern
from axiart.patterns.grid import GridPattern
from axiart.patterns.noise import NoisePattern

def generate_png_preview(svg_path, png_path=None, width=2400):
    """
    Generate PNG preview from SVG using Inkscape or cairosvg

    Args:
        svg_path: Path to the SVG file
        png_path: Output PNG path (defaults to same name as SVG)
        width: Width in pixels (default 2400 for high quality)
    """
    if png_path is None:
        png_path = svg_path.replace('.svg', '.png')

    # Try Inkscape first (best quality)
    try:
        subprocess.run([
            'inkscape',
            '--export-type=png',
            f'--export-width={width}',
            '--export-filename=' + png_path,
            svg_path
        ], check=True, capture_output=True)
        print(f"✓ PNG preview: {png_path}")
        return png_path
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Fallback to cairosvg
    try:
        import cairosvg
        cairosvg.svg2png(
            url=svg_path,
            write_to=png_path,
            output_width=width
        )
        print(f"✓ PNG preview: {png_path}")
        return png_path
    except ImportError:
        print("⚠ Could not generate PNG - install cairosvg or inkscape")
        print(f"  pip install cairosvg")
        return None

def point_in_circle(x, y, cx, cy, r):
    """Check if point is inside circle"""
    return (x - cx)**2 + (y - cy)**2 < r**2

def filter_to_zone(points, zone_center, zone_radius):
    """Keep only points inside circular zone"""
    cx, cy = zone_center
    return [(x, y) for x, y in points
            if (x - cx)**2 + (y - cy)**2 < zone_radius**2]

def filter_outside_zones(points, zones):
    """Keep only points outside ALL zones (for background patterns)
    zones = list of dicts with 'cx', 'cy', 'r' keys
    """
    return [(x, y) for x, y in points
            if all((x - z['cx'])**2 + (y - z['cy'])**2 > z['r']**2
                   for z in zones)]

def filter_to_band(points, y_min, y_max):
    """Keep only points in horizontal band (for landscapes)"""
    return [(x, y) for x, y in points if y_min <= y <= y_max]

def filter_to_quadrant(points, cx, cy, quadrant):
    """Keep only points in specified quadrant
    quadrant: 'upper-left', 'upper-right', 'lower-left', 'lower-right'
    """
    if quadrant == 'upper-left':
        return [(x, y) for x, y in points if x < cx and y < cy]
    elif quadrant == 'upper-right':
        return [(x, y) for x, y in points if x >= cx and y < cy]
    elif quadrant == 'lower-left':
        return [(x, y) for x, y in points if x < cx and y >= cy]
    elif quadrant == 'lower-right':
        return [(x, y) for x, y in points if x >= cx and y >= cy]
    return points

def main():
    # Canvas setup
    comp = Composition(width=297, height=210, background="white")
    
    # Layer architecture
    comp.add_layer("grid", color="#CCCCCC", stroke_width=0.2, opacity=0.5)
    comp.add_layer("geo_fills", color="none")
    comp.add_layer("geo_strokes", color="black", stroke_width=0.4)
    comp.add_layer("primary_pattern", color="black", stroke_width=0.25)
    comp.add_layer("secondary_pattern", color="black", stroke_width=0.2)
    comp.add_layer("tertiary_pattern", color="black", stroke_width=0.2, opacity=0.7)
    comp.add_layer("annotations", color="black", stroke_width=0.3)
    comp.add_layer("accent_color", color="#2E4A6D", stroke_width=0.6)
    
    canvas = comp.get_canvas()
    width, height = 297, 210
    cx, cy = width/2, height/2
    
    print("\n" + "="*60)
    print(f"GENERATING: [Title]")
    print("="*60)
    
    # STEP 1: Grid foundation
    print("\n[1/6] Establishing grid infrastructure...")
    grid = GridPattern(width, height)
    grid.generate_square_grid(cell_size=10, jitter=0.1)
    for line in grid.get_lines():
        canvas.add_polyline(line, "grid")
    grid_marks = len(grid.get_lines()) * 2  # Approximate
    print(f"      Grid: {grid_marks} marks")
    
    # STEP 2: Geometric zones (example: portrait with 3 circles)
    print("\n[2/6] Creating geometric infrastructure...")
    
    # Define geometric zones
    zones = []
    
    # Left eye zone - SEMI-TRANSPARENT fill (patterns draw OVER it)
    canvas.dwg.add(canvas.dwg.circle(
        center=(cx - 40, cy - 30),
        r=35,
        fill="#E3F2FD",      # Very light blue tint
        opacity=0.25,        # Semi-transparent (not opaque!)
        stroke="#2E4A6D",    # Blue accent outline (solid)
        stroke_width=0.6
    ))
    zones.append({"cx": cx - 40, "cy": cy - 30, "r": 35})

    # Right eye zone - SEMI-TRANSPARENT fill
    canvas.dwg.add(canvas.dwg.circle(
        center=(cx + 40, cy - 30),
        r=35,
        fill="#E3F2FD",      # Very light blue tint
        opacity=0.25,        # Semi-transparent
        stroke="#2E4A6D",    # Blue accent outline
        stroke_width=0.6
    ))
    zones.append({"cx": cx + 40, "cy": cy - 30, "r": 35})

    # Central processing zone - SEMI-TRANSPARENT fill
    canvas.dwg.add(canvas.dwg.circle(
        center=(cx, cy + 15),
        r=45,
        fill="#E3F2FD",      # Very light blue tint
        opacity=0.25,        # Semi-transparent
        stroke="#2E4A6D",    # Blue accent outline
        stroke_width=0.6
    ))
    zones.append({"cx": cx, "cy": cy + 15, "r": 45})
    
    geo_marks = 600  # Approximate for circles
    print(f"      Geometric zones: 3 circles, ~{geo_marks} marks")
    
    # STEP 3: Primary pattern system (dense, inside zones)
    print("\n[3/6] Generating primary pattern system...")
    primary_marks = 0

    # Fermat spirals in each zone - draw as continuous curves, not points
    for zone in zones:
        spiral = SpiralPattern(width, height, center=(zone["cx"], zone["cy"]))
        spiral.generate_fermat_spiral(num_points=2500, spacing=1.5)
        paths = spiral.get_spirals()  # Get actual spiral curves
        for spiral_path in paths:
            canvas.add_polyline(spiral_path, "primary_pattern")
            primary_marks += len(spiral_path)

    print(f"      Primary (spirals): {primary_marks} marks")
    
    # STEP 4: Secondary pattern system (dendrites from zone boundaries)
    print("\n[4/6] Generating secondary pattern system...")
    
    # Dendrites seeded from zone boundaries
    seeds = []
    for zone in zones:
        # Create seeds around circle perimeter
        for angle in range(0, 360, 30):
            rad = angle * 3.14159 / 180
            sx = zone["cx"] + zone["r"] * 0.9 * cos(rad)
            sy = zone["cy"] + zone["r"] * 0.9 * sin(rad)
            seeds.append((sx, sy))
    
    dendrite = DendritePattern(width, height,
                               num_particles=4000,
                               attraction_distance=8,
                               seed_points=seeds[:20],  # Use subset
                               branching_style="radial")
    dendrite.generate()
    
    # Filter: only render dendrites OUTSIDE zones (they grow outward)
    dendrite_lines = dendrite.get_lines()
    secondary_marks = 0
    for line in dendrite_lines:
        # Check if line midpoint is outside all zones
        mid_x = (line[0][0] + line[1][0]) / 2
        mid_y = (line[0][1] + line[1][1]) / 2
        
        outside_all = all(
            not point_in_circle(mid_x, mid_y, z["cx"], z["cy"], z["r"])
            for z in zones
        )
        
        if outside_all:
            canvas.add_line(line[0], line[1], "secondary_pattern")
            secondary_marks += 1
    
    print(f"      Secondary (dendrites): {secondary_marks} marks")
    
    # STEP 5: Tertiary pattern (flow fields between zones)
    print("\n[5/6] Generating tertiary pattern system...")
    
    flow = FlowFieldPattern(width, height, field_type="noise", scale=40)
    flow.generate_streamlines(num_lines=1000, steps=80, step_size=1.5)
    
    # Filter: render in transition zones (medium density between zones)
    flow_paths = flow.get_paths()
    tertiary_marks = 0
    for path in flow_paths:
        avg_x = sum(x for x, y in path) / len(path)
        avg_y = sum(y for x, y in path) / len(path)
        
        # Not inside zones, but not too far away either
        dists = [(avg_x - z["cx"])**2 + (avg_y - z["cy"])**2 for z in zones]
        min_dist = min(dists)
        
        if min_dist > (50**2) and min_dist < (90**2):  # Transition ring
            canvas.add_polyline(path, "tertiary_pattern")
            tertiary_marks += len(path)
    
    print(f"      Tertiary (flow field): {tertiary_marks} marks")
    
    # STEP 6: Annotations
    print("\n[6/6] Adding clinical annotations...")
    
    # Coordinate markers at zone centers
    for zone in zones:
        canvas.set_layer("annotations")
        # Small circle
        marker = Circle((zone["cx"], zone["cy"]), 1.5)
        canvas.add_polyline(marker.get_points(), "annotations")
        # Crosshair
        canvas.add_polyline([
            (zone["cx"] - 3, zone["cy"]), 
            (zone["cx"] + 3, zone["cy"])
        ], "annotations")
        canvas.add_polyline([
            (zone["cx"], zone["cy"] - 3), 
            (zone["cx"], zone["cy"] + 3)
        ], "annotations")
    
    # Measurement ticks on edges
    for x in range(20, 280, 20):
        canvas.add_polyline([(x, 5), (x, 8)], "annotations")
        canvas.add_polyline([(x, 202), (x, 205)], "annotations")
    
    annotation_marks = 200  # Approximate
    print(f"      Annotations: {annotation_marks} marks")

    # Save SVG
    output_path = "[filename].svg"
    comp.save(output_path)

    # Generate PNG preview
    generate_png_preview(output_path)

    # Statistics
    total_marks = grid_marks + geo_marks + primary_marks + secondary_marks + tertiary_marks + annotation_marks
    
    print("\n" + "="*60)
    print("✓ GENERATION COMPLETE")
    print("="*60)
    print(f"Total marks: ~{total_marks:,} elements")
    print(f"Output: {output_path}")
    print(f"Ready for plotting + hand-coloring")
    print("="*60)

if __name__ == "__main__":
    main()
```

## Philosophy Document Template

```markdown
# [Title]

## Technical Documentation Of: [Subject/Concept]

[2-3 paragraphs describing:]

**What invisible architecture is being mapped:**
- What processes, forces, or structures are being documented
- Why this subject requires technical/scientific visualization
- What the geometric infrastructure represents

**How patterns document the architecture:**
- Primary pattern role (what it maps/reveals)
- Secondary pattern role (how it interacts/fragments/supports)
- Tertiary pattern role (additional depth/complexity)

**How color zones function structurally:**
- What accent color 1 delineates (boundaries, connections, emphasis)
- What accent color 2 does (if used)
- How color guides interpretation without being decorative

**Density distribution strategy:**
- Where dense marks accumulate and why
- Where sparse zones exist and their purpose
- How the viewer's eye is guided through the composition

## Technical Specifications

- Canvas: 297mm × 210mm (A4 landscape)
- Total marks: ~[count] elements
- Pattern systems: [list 2-3]
- Geometric infrastructure: [grid + shapes]
- Color palette: Black + [accent colors]
- Estimated plotting time: [hours] at standard speed

## Hand-Coloring Guide

After plotting in black:

1. **[Accent color 1]:** Apply to [specific zones/elements]
2. **[Accent color 2]:** Apply to [specific zones/elements] (if used)
3. **Fill zones:** Light washes in [geometric shapes] if desired

The piece is designed to be impactful in black only, with color enhancing structural elements.
```

---

**This skill generates work with visual impact and technical craft - dense, layered, geometric, striking.**